// Copyright 2020 Juan Marcelo Portillo. All Rights Reserved.


#include "FocusableObject.h"

// Add default functionality here for any IFocusableObject functions that are not pure virtual.
